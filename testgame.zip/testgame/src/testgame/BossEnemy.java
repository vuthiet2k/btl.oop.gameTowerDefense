package testgame;


public class BossEnemy extends Enemy
{
	
	BossEnemy(PathPosition p)
	{
		ImageLoader loader = ImageLoader.getLoader();
		this.enemy = loader.getImage("resources/Boss.png");
		this.position = p;
		this.anchorX = -25;
		this.anchorY = -25;
		this.velocity = 2;
                this.hp = 100;
	}
	
}
