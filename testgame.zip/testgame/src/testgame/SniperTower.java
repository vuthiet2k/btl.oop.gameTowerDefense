package testgame;

import java.util.List;


public class SniperTower extends Tower
{
	
	public SniperTower(Coordinate pos)
	{
		ImageLoader loader = ImageLoader.getLoader();
		this.tower = loader.getImage("resources/sniper.png");
		this.position = pos;
		this.anchorX = -30;
		this.anchorY = -30;
	}

    
	
	public void interact(Game game, double deltaTime)
	{	
                // thoi gian dan ton tai
		timeSinceLastFire += deltaTime;
		
		if(timeSinceLastFire < 1.5)
			return;
		
		List<Enemy> enemies = game.enemies; 
		
		for(Enemy e: enemies)
		{	
			
			Coordinate enemyPos = e.getPosition().getCoordinate();

			double dx, dy, dist;	
			
			dx = enemyPos.x - position.x; 
			dy = enemyPos.y - position.y; 
		
			dist = Math.sqrt((dx*dx) + (dy*dy));
			
			Coordinate pos = new Coordinate(position.x, position.y);	
			
			if(dist < 160)
			{	
                                Bullet_SniperTower bs = new Bullet_SniperTower(pos, enemyPos);
				game.effects.add(bs);
				timeSinceLastFire = 0;
				return;
			}	
		} 
	}	
}
