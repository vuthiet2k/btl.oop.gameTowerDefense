package testgame;

import java.util.List;


public class NormalTower extends Tower
{
	
	public NormalTower(Coordinate pos)
	{
		ImageLoader loader = ImageLoader.getLoader();
		this.tower = loader.getImage("resources/tru1.png");
		this.position = pos;
		this.anchorX = -40;
		this.anchorY = -40;
	}
	
	
	public void interact(Game game, double deltaTime)
	{	
                // thoi gian dan ton tai
		timeSinceLastFire += deltaTime;
		
		if(timeSinceLastFire < 1)
			return;
		
		List<Enemy> enemies = game.enemies; 
		
		for(Enemy e: enemies)
		{	
			
			Coordinate enemyPos = e.getPosition().getCoordinate();

			double dx, dy, dist;	
			
			dx = enemyPos.x - position.x; 
			dy = enemyPos.y - position.y; 
		
			dist = Math.sqrt((dx*dx) + (dy*dy));
			
			Coordinate pos = new Coordinate(position.x, position.y);	
			
			if(dist < 100)
			{	Bullet_NormalTower stardust = new Bullet_NormalTower(pos, enemyPos);
				game.effects.add(stardust);
				timeSinceLastFire = 0;
				return;
			}	
		} 
	}	
}