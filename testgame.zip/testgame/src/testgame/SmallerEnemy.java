package testgame;


public class SmallerEnemy extends Enemy
{
	
	SmallerEnemy(PathPosition p)
	{
		ImageLoader loader = ImageLoader.getLoader();
		this.enemy = loader.getImage("resources/smaller.png");
		this.position = p;
		this.anchorX = -25;
		this.anchorY = -25;
		this.velocity = 8;
                this.hp = 10;
	}
	
}