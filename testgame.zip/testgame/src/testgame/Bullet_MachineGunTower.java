package testgame;




public class Bullet_MachineGunTower extends Bullet 
{
	public Bullet_MachineGunTower(Coordinate pos, Coordinate target)
	{
		
		ImageLoader loader = ImageLoader.getLoader();
		this.picture = loader.getImage("resources/cau_lua.png");
		
		
		this.posX = pos.x;
		this.posY = pos.y;		
		
		
		this.velocityX = target.x - this.posX;
		this.velocityY = target.y - this.posY;
		
		
		this.ageInSeconds = 0;
                this.dame = 8;
	}
        
        
}
