package testgame;

import java.awt.Graphics;
import java.awt.Image;


abstract public class Enemy 
{
	protected PathPosition position;	
	protected Image enemy;				
	protected int anchorX;				
	protected int anchorY;				
	protected double velocity; 		
        protected int hp;
	
	public void advance()
	{
		position.advance(1 + velocity);
	}
		
	public void draw(Graphics g)
	{		
		Coordinate c = position.getCoordinate();
		g.drawImage(enemy, c.x + anchorX, c.y + anchorY, null);
				
	}
	
	public PathPosition getPosition()
	{
		return position;
	}	
       
}
