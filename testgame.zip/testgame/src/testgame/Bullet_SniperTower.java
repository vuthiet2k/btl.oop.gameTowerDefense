package testgame;


public class Bullet_SniperTower extends Bullet 
{
	public Bullet_SniperTower(Coordinate pos, Coordinate target)
	{
		
		ImageLoader loader = ImageLoader.getLoader();
		this.picture = loader.getImage("resources/sun_spot.png");
		
		
		this.posX = pos.x;
		this.posY = pos.y;		
		
		
		this.velocityX = target.x - this.posX;
		this.velocityY = target.y - this.posY;
		
		
		this.ageInSeconds = 0;
                this.dame = 20;
	}	
}