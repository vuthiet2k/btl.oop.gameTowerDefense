package testgame;

import java.awt.*;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


enum GameState { SETUP, UPDATE, DRAW, WAIT, END }


public class Game implements Runnable
{
    
    public static void main (String[] args)
    {      
        
        new Game ();
         
    }
    
    private Image backdrop;						
    private PathPoints line;			
    
    private GamePanel gamePanel;		
    private GameState state;	   		// The current game state
    
    private int frameCounter;			// keeps track of frame updates
    private long lastTime;				// keeps track of time
    
    private boolean placingNormalTower;	
    private Tower newNormalTower; 		
    private double elapsedTime;			
    
    private boolean placingMachineGunTower;	// true if tower is being placed
    private Tower newMachineGunTower; 		// variable to hold new tower objects
    private boolean gameIsOver;			// indicates if game is lost
    private boolean gameIsWon;			// indicates if game is won
    
    private boolean placingSniperTower;
    private Tower newSniperTower;
    
    int livesCounter; 					
    int scoreCounter;					
    int killsCounter;					
    
    
    List<Enemy> enemies;				
    
    
    List<Tower> towers;					
    
    
    List<Bullet> effects;				
    
    
    public Game ()
    {
        // The game starts in the SETUP state.
        
        state = GameState.SETUP;
        gamePanel = new  GamePanel(this);        
        
        Thread t = new Thread(this);
        t.start();  
    }
    
    public void run ()
    {
        
        while (true)
        {                       
            if (state == GameState.SETUP)
            {
                doSetupStuff();
            }
            
            else if (state == GameState.UPDATE)
            {
                doUpdateTasks();
            }
            
            else if (state == GameState.DRAW)
            {               
                
                gamePanel.repaint();  // ve lai man hinh
                
                try { Thread.sleep(5); } catch (Exception e) {}
               
            }
            
            else if (state == GameState.WAIT)
            {
               
                try { Thread.sleep(100); } catch (Exception e) {}
                
                state = GameState.UPDATE;
            }
            
            else if (state == GameState.END)
            {
                // lam sach
            }
        }
    }
    
    
    private void doSetupStuff ()
    {
        
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        f.setTitle("Tower Defense Game");
        f.setContentPane(gamePanel);
        f.pack();
        f.setVisible(true); 
        
    	// tai hinh nen
		ImageLoader loader = ImageLoader.getLoader();
        backdrop = loader.getImage("resources/backdrop.png");
        
        JOptionPane.showMessageDialog(null,  "Luật chơi & và cách chơi\n" +
        		"1. Nhấn chuột trái vào chỗ mua tháp rồi di chuyển đến chỗ cần đặt, ấn lần nữa để đặt tháp.\n" +
        		"2. Giết quái để nhận được tiền mua thêm tháp.\n" +
        		"3. Giết quái được nhận điểm, đủ 500 điểm bạn sẽ win.\n" +
        		"4. Quá 10 quái vật đến đích bạn sẽ thua.");
        
        
        livesCounter = 10;		
        scoreCounter = 1000;		
        killsCounter = 0;		
        
        frameCounter = 0;
        lastTime = System.currentTimeMillis();
        
            ClassLoader myLoader = this.getClass().getClassLoader();
        InputStream pointStream = myLoader.getResourceAsStream("resources/path_1.txt");
        Scanner s = new Scanner (pointStream);
        line  = new PathPoints(s);
        
        enemies = new LinkedList<Enemy>();
                
        towers = new LinkedList<Tower>();
        
        effects = new LinkedList<Bullet>();
        
        placingNormalTower = false;
        newNormalTower = null;
        
        placingMachineGunTower = false;
        newMachineGunTower = null;
        
        placingSniperTower = false;
        newSniperTower = null;
        	
        gameIsOver = false;
    	gameIsWon = false;
        
        
        state = GameState.UPDATE;  // You could also enter the 'DRAW' state.
    }
    
    
    private void doUpdateTasks()
    {	
    	if(gameIsOver)
    	{	state = GameState.DRAW;
    		return;
    	}
    	
    	if(gameIsWon)
    	{	state = GameState.DRAW;
    		return;
    	}
    	
    	
        long currentTime = System.currentTimeMillis();  
        elapsedTime = ((currentTime - lastTime) / 1000.0); 
        lastTime = currentTime;  
    	
         	
    	for(Tower t: new LinkedList<Tower>(towers))
    	{	
    		t.interact(this, elapsedTime);
    		
    	}
             
    	for(Bullet e: new LinkedList<Bullet>(effects))
    	{	
    		e.interact(this, elapsedTime);
    		if(e.isDone())
    			effects.remove(e);	
    	}
    	
    	
    	for(Enemy e: new LinkedList<Enemy>(enemies))
    	{	
    		e.advance();
     		if(e.getPosition().isAtTheEnd() && e.hp >= 0)
    		{
    			enemies.remove(e);	
    			livesCounter--;		
    		}

    	}
    	
        
        this.generateEnemies();
        
    	
    	frameCounter++;
    	
    	
    	this.placeNormalTowers();
    	this.placeMachineGunTowers();
        this.placeSniperTowers();
    	
    	if(livesCounter <= 0)
    	{	gameIsOver = true;
    		livesCounter = 0;
    	}
    	
    	if(killsCounter >= 500)
    	{	gameIsWon = true;
    		killsCounter = 500;
    	}
    	
        
        state = GameState.DRAW;
       
    }
    
    
    public void draw(Graphics g)
    {
        
        
        if (state != GameState.DRAW)
            return;
        	
        
        g.drawImage(backdrop, 0, 0, null); 
     
        
        g.setColor(new Color (0,76, 153));
        //int[] xPos = new int[]{0, 64, 118, 251, 298, 344, 396, 416, 437, 459, 460, 498, 542, 600, 600, 568, 535, 509, 490, 481, 456, 414, 345, 287, 227, 98, 0};
        //int[] yPos = new int[]{329, 316, 291, 189, 163, 154, 165, 186, 233, 344, 364, 415, 444, 461, 410, 396, 372, 331, 226, 195, 151, 117, 105, 117, 143, 244, 280};
        int[] xPos = new int[]{0  , 300, 300, 500, 500, 800, 800, 550, 550, 250, 250,   0};
        int[] yPos = new int[]{330, 330, 170, 170, 460, 460, 410, 410, 120, 120, 280, 280};
        g.fillPolygon(xPos, yPos, 12);
        
         
        g.setColor(new Color(65,105,225));
        g.fillArc(760, 385, 100, 100, 90, 180);
        //g.setColor(Color.GREEN);
        //int[] xCor = new int[]{600, 588, 574, 566, 557, 557, 563, 572, 576, 584, 600};
        //int[] yCor = new int[]{409, 464, 462, 453, 454, 448, 438, 435, 422, 414, 415};
        //g.fillPolygon(xCor, yCor, 11);
       
        
    	for(Enemy e: new LinkedList<Enemy>(enemies))
    		e.draw(g);
        

        for(Tower t: new LinkedList<Tower>(towers))
        	t.draw(g);
        	
    	
    	for(Bullet s: new LinkedList<Bullet>(effects))
    		s.draw(g);
    	
        
        g.setColor(Color.WHITE);
        g.fillRect(800, 0, 200, 800);
        
        
        g.setColor(Color.BLACK);
        g.setFont(new Font("Lucidia Sans", Font.BOLD, 16));
        g.drawString("Lives Remaining: " + livesCounter, 805, 90);	// lives counter
        g.drawString("Money Earned: " + scoreCounter, 805, 120);	// score counter
        g.drawString("Enemies Stopped: " + killsCounter, 805, 150);
        g.drawString("Normal Cost: 100", 832, 305);				// cost for black hole towers
        g.drawString("MachineGun Cost: 300", 815, 445);	
        g.drawString("Sniper Cost: 300", 830, 567);	
        g.setColor(Color.RED);
        g.setFont(new Font("Lucidia Sans", Font.PLAIN, 25));		
        g.drawString("Planet Defense", 815, 45);					// writes title
        g.drawLine(800, 50, 1000, 50);								// underscore
        g.drawString("Towers", 850, 185);							// writes towers
        g.drawLine(830, 190, 950, 190);								// underscore	
        
        
        g.setColor(new Color(224, 224, 224));
        g.fillRect(858, 205, 80, 80);
        
        
        NormalTower normaltower = new NormalTower(new Coordinate(900, 245));
        normaltower.draw(g);
        
        
        g.setColor(new Color(224, 224, 224));
        g.fillRect(850, 325, 100, 100);
        
        
        MachineGunTower machineguntower = new MachineGunTower(new Coordinate(900, 375));
        machineguntower.draw(g);
        
        g.setColor(new Color(224, 224, 224));
        g.fillRect(858, 465, 80, 80);
        
        SniperTower sniperTower = new SniperTower(new Coordinate(900, 500));
        sniperTower.draw(g);
        
        
        
        if(newNormalTower != null)
        	newNormalTower.draw(g);

        
        if(newMachineGunTower != null)
        	newMachineGunTower.draw(g);
        
        if(newSniperTower != null)
        	newSniperTower.draw(g);
        
        ImageLoader loader = ImageLoader.getLoader();	
		Image endGame = loader.getImage("resources/game_over.png"); 
    	
        if(livesCounter <= 0)										
        	g.drawImage(endGame, 0, 0, null);						

		if(killsCounter >= 500)	                    
		{
                    g.setColor(Color.RED);
                    g.setFont(new Font("Braggadocio", Font.ITALIC, 90));		
                    g.drawString("YOU WIN!!!", 10, 250);					// draw "game over"
		}
		
        
        state = GameState.WAIT;
    }
    
    
    public void generateEnemies()
    {	
    	
    	if(frameCounter % 30 == 0 && frameCounter < 100)		 
    	{
    		enemies.add(new NormalEnemy(line.getStart()));
    	}
 	/*else if(frameCounter % 25 == 0 && frameCounter >= 50)	
 	{
 		enemies.add(new NormalEnemy(line.getStart())); 
 	}*/
	else if(frameCounter % 40 == 0 && frameCounter >= 150 && frameCounter < 330)	
	 {
	 	//enemies.add(new NormalEnemy(line.getStart())); 
	 	enemies.add(new TankerEnemy(line.getStart()));
	 }	
 	else if(frameCounter % 20 == 0 && frameCounter >= 420 && frameCounter < 580)	
 	{
 		enemies.add(new NormalEnemy(line.getStart())); 
 		enemies.add(new TankerEnemy(line.getStart()));
 	}
	else if(frameCounter % 20 == 0 && frameCounter >= 670)	
	{
	 	//enemies.add(new NormalEnemy(line.getStart())); 
	 	//enemies.add(new TankerEnemy(line.getStart()));
	 	enemies.add(new SmallerEnemy(line.getStart()));
	}
	else if(frameCounter % 50 == 0 && frameCounter >= 760 && frameCounter <= 930)	
	{
//	 	enemies.add(new NormalEnemy(line.getStart())); 
//	 	enemies.add(new TankerEnemy(line.getStart()));
//	 	enemies.add(new SmallerEnemy(line.getStart()));
                enemies.add(new BossEnemy(line.getStart()));
	}
        else if(frameCounter % 15 == 0 && frameCounter >= 1030){
            enemies.add(new NormalEnemy(line.getStart())); 
            enemies.add(new TankerEnemy(line.getStart()));
            enemies.add(new SmallerEnemy(line.getStart()));
            enemies.add(new BossEnemy(line.getStart()));
        }
            
    }
    
    
    public void placeNormalTowers()
    {
    	
    	
    	Coordinate mouseLocation = new Coordinate(gamePanel.mouseX, gamePanel.mouseY);
    	
    	
    	if(gamePanel.mouseX > 850 && gamePanel.mouseX < 950 && 
    		gamePanel.mouseY > 195 && gamePanel.mouseY < 295 && 
    		gamePanel.mouseIsPressed && scoreCounter >= 100)
    	{	
	    		placingNormalTower = true;
	    		newNormalTower = new NormalTower(mouseLocation);
    	}    
    	else if(gamePanel.mouseX > 0 && gamePanel.mouseX < 800 && 
        	gamePanel.mouseY > 0 && gamePanel.mouseY < 800 && 
        	gamePanel.mouseIsPressed && placingNormalTower
        	&& line.distanceToPath(gamePanel.mouseX, gamePanel.mouseY) > 60
                && line.distanceToPath(gamePanel.mouseX, gamePanel.mouseY) < 150)
    	{	
	    		newNormalTower.setPosition(mouseLocation);
	    		towers.add(new NormalTower(mouseLocation));
	    		scoreCounter -= 100;
	    		newNormalTower = null;
	    		placingNormalTower = false;	
    	}
    	
    	
    	if(newNormalTower != null)
    	{
    		newNormalTower.setPosition(mouseLocation);
    	}	
    }
    
    
    public void placeMachineGunTowers()
    {
    	
    	Coordinate mouseLocation = new Coordinate(gamePanel.mouseX, gamePanel.mouseY);
    	
    	
    	if(gamePanel.mouseX > 850 && gamePanel.mouseX < 950 && 
    		gamePanel.mouseY > 325 && gamePanel.mouseY < 425 && 
    		gamePanel.mouseIsPressed && scoreCounter >= 300)
    	{	
	    		placingMachineGunTower = true;
	    		newMachineGunTower = new MachineGunTower(mouseLocation);
    	}    
    	else if(gamePanel.mouseX > 0 && gamePanel.mouseX < 800 && 
        	gamePanel.mouseY > 0 && gamePanel.mouseY < 800 && 
        	gamePanel.mouseIsPressed && placingMachineGunTower
        	&& line.distanceToPath(gamePanel.mouseX, gamePanel.mouseY) > 60
                && line.distanceToPath(gamePanel.mouseX, gamePanel.mouseY) < 150)
    	{	
	    		newMachineGunTower.setPosition(mouseLocation);
	    		towers.add(new MachineGunTower(mouseLocation));
	    		scoreCounter -= 300;
	    		newMachineGunTower = null;
	    		placingMachineGunTower = false;	
    	}
    	
    	
    	if(newMachineGunTower != null)
    	{
    		newMachineGunTower.setPosition(mouseLocation);
    	}	
    }
    
    public void placeSniperTowers()
    {
    	
    	Coordinate mouseLocation = new Coordinate(gamePanel.mouseX, gamePanel.mouseY);
    	
    	
    	if(gamePanel.mouseX > 850 && gamePanel.mouseX < 950 && 
    		gamePanel.mouseY > 450 && gamePanel.mouseY < 550 && 
    		gamePanel.mouseIsPressed && scoreCounter >= 300)
    	{	
	    		placingSniperTower = true;
	    		newSniperTower = new SniperTower(mouseLocation);
    	}    
    	else if(gamePanel.mouseX > 0 && gamePanel.mouseX < 800 && 
        	gamePanel.mouseY > 0 && gamePanel.mouseY < 800 && 
        	gamePanel.mouseIsPressed && placingSniperTower
        	&& line.distanceToPath(gamePanel.mouseX, gamePanel.mouseY) > 60
                && line.distanceToPath(gamePanel.mouseX, gamePanel.mouseY) < 200)
    	{	
	    		newSniperTower.setPosition(mouseLocation);
	    		towers.add(new SniperTower(mouseLocation));
	    		scoreCounter -= 300;
	    		newSniperTower = null;
	    		placingSniperTower = false;	
    	}
    	
    	
    	if(newSniperTower != null)
    	{
    		newSniperTower.setPosition(mouseLocation);
    	}	
    }
}	